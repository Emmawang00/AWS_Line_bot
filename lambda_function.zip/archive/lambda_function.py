from linebot import LineBotApi, WebhookHandler
from linebot.exceptions import InvalidSignatureError
from linebot.models import (
    MessageEvent,
    TextMessage,
    TextSendMessage,
)
import json
import logging
import os

logger = logging.getLogger()
logger.setLevel(logging.ERROR)

line_bot_api = LineBotApi(
    os.getenv(
        "M6vMnarbRwugMKMST31tbuj2OLi8ntIkkHjO02LzIT1MKpy4sT8OOpfuRCm9YD+a7MwXPhtnB7N6WUyn63/355YLZvRe1bdw8f9p/asTmCZZorBJV5eUeHPsY+W0zKgtbzfRLXdNd2wTw17ZbRyIlAdB04t89/1O/w1cDnyilFU="
    )
)
handler = WebhookHandler(os.getenv("8cd122cdfe375a57ed8dc8ef687abbe2"))


def lambda_handler(event, context):
    @handler.add(MessageEvent, message=TextMessage)
    def handle_message(event):
        line_bot_api.reply_message(
            event.reply_token, TextSendMessage(text=event.message.text)
        )

    try:
        # get X-Line-Signature header value
        signature = event["headers"]["X-Line-Signature"]
        # get event body
        body = event["body"]
        # handle webhook body
        handler.handle(body, signature)
    except InvalidSignatureError:
        return {"statusCode": 400, "body": "InvalidSignature"}
    except Exception as e:
        return {"statusCode": 400, "body": json.dump(e)}
    return {"statusCode": 200, "body": "OK"}
